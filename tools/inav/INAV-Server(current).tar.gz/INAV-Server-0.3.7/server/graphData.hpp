#ifndef GRAPHDATA_H
#define GRAPHDATA_H

typedef int ipv4;
typedef long int ipv6;

template <typename T>
class GraphData {
  protected:

  public:
    GraphData () {}

    virtual ~GraphData() {}

    virtual void addEdge( T ipA, T ipB, uint32_t weight 

};

typedef GraphData* create_t();
typedef void destroy_t( GraphData* );

#endif
