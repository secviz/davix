#include "node.hpp"

Node::Node()
{
}

void Node::setNodeID( T id )
{
  id_ = id;
}

T Node::getNodeID( )
{
  return id_;
}

void Node::setNodeColor( uint32_t color )
{
  color_ = color;
}

uint32_t Node::getNodeColor( )
{
  return color_;
}

void Node::setNodeShape( Shape shape )
{
  shape_ = shape;
}

Shape Node::getNodeShape( )
{
  return shape_;
}
