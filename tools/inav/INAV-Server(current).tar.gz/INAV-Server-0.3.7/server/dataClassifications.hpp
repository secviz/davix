#ifndef DATACLASSIFICATIONS_HPP
#define DATACLASSIFICATIONS_HPP

typedef struct DataClassifications
{
  bool ipv4;
  bool ipv6;
  bool string;
  std::string description; //if using the generic string data type we need a way to name this data.
} DataClassifications;

#endif
